Foster Lockwood
COMP20 - Assignment 5

1. The POST and GET API endpoints have been implemented as described in the assignment documentation, as well as a basic web (HTML) interface for seeing the high scores for all the games and a "usersearch" page where one can see scores pertaining to just one user.

2. I did not collaborate with anyone on this assigment. The links included in the assigment description were incredibly helpful though.

3. I spent about 6 hours on this assignment.