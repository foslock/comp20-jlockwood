var express = require('express');
var app = express.createServer(express.logger());
app.use(express.bodyParser());

// Connects to MongoDB database (creates if doesn't exist)
var databaseUrl = "mongodb://heroku:a417028df2076c3e8c7718a242e45657@linus.mongohq.com:10086/app14159757";
var collections = ["highscores"];
var db = require("mongojs").connect(databaseUrl, collections);

// Uncomment if database needs clearing
// db.highscores.remove();

// Enables CORS for all other requests
app.all('*', function(req, res, next) {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'PUT, GET, POST, DELETE, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Content-Type');
  next();
});

app.post('/submit.json', function(request, response) {
	// Get and save the following data:
	// "game_title" => Title
	// "username" => Username associated with score
	// "score" => Score value

	var title = request.param('game_title');
	var username = request.param('username');
	var score = request.param('score');

	console.log([title, username, score]);
	if (!title || !username || !score) {
		response.send({
			success: 0, 
			error: "Required values: 'game_title', 'username', and 'score'"});
		return;
	}

	var date = new Date();
	db.highscores.save({
		game_title: title,
		username: username,
		score: score,
		created_at: date.toUTCString()}, function(err, saved) {
			var succ = 1;
			if (err || !saved) { 
				console.log("ERROR: Score not saved!");
				succ = 0;
			} else {
				console.log("Saved!");
			}
  			response.send({success: succ});
	});
});

app.get('/highscores.json', function(request, response) {
  	// Returns the top 10 scores as a json object
  	// "game_title" => Title of game for desired scores

  	var title = request.param('game_title');
  	if (!title) {
  		response.send({success: 0, error: "Game title required"});
  		return;
  	}
  	db.highscores.find({game_title: title}, function(err, scores) {
  		var succ = 1;
  		var returnScores = [];
		if (err || !scores) {
			console.log("ERROR: Game not found!");
			succ = 0;
		} else if (scores.length > 0) {
			scores.sort(function(a, b) {
				return b.score - a.score;
			});
			var count = Math.min(scores.length, 10);
			for (var i = 0; i < count; i++) {
				returnScores.push(scores[i]);
			}
		}
		// response.send({success: succ, data: returnScores});
		response.send(returnScores);
  	});
});

app.get('/allscores.json', function(request, response) {
  	// Returns all scores
  	db.highscores.find(function(err, scores) {
  		var succ = 1;
  		var returnScores = [];
		if (err || !scores) {
			console.log("ERROR: Scores not found!");
			succ = 0;
		} else if (scores.length > 0) {
			for (var i = 0; i < scores.length; i++) {
				returnScores.push(scores[i]);
			}
		}
		response.send({success: succ, data: returnScores});
  	});
});

app.get('/', function(request, response) {
  	// Home page
  	response.sendfile(__dirname + '/public/index.html');
});

app.get('/usersearch', function(request, response) {
  	// Page with username input, shows scores for that user
  	response.sendfile(__dirname + '/public/usersearch.html');
});

// This function gets any resources that aren't part of the API (in the public folder)
app.get(/\/(.+)\.(html|css|js)/, function(request, response) {
	var params = request.route.params;
	response.sendfile(__dirname + '/public/' + params[0] + '.' + params[1]);
});

var port = process.env.PORT || 5000;
app.listen(port, function() {
  console.log("Listening on " + port);
});
