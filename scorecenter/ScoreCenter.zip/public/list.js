var showList = function() {
	$.getJSON('./allscores.json', function(data) {
		var list = [];
		var games = [];
		var scorelist = data['data'];
		scorelist.sort(function(a, b) {
			return b['score'] - a['score'];
		})

		$.each(scorelist, function(index, score) {
			if (score['game_title'] &&
				$.inArray(score['game_title'], games) == -1) {
				games.push(score['game_title']);
			}
		});

		$.each(games, function(index, game) {
			$('<h3/>', {
				'class': 'gameheader',
				html: game
			}).appendTo('#gamelist');

			var listEle = $('<table/>', {
				'class': 'scoretable',
				'border': '2',
				html: ""
			});
			var html = "<tr><th>User</th><th>Score</th><th>Time</th></tr>";
			$.each(scorelist, function(j, score) {
				if (game && score['game_title'] == game) {
					var newHTML = "";
					newHTML = "<tr><td>" + score['username'] + "</td>";
					newHTML += "<td>" + score['score'] + "</td>";
					newHTML += "<td>" + score['created_at'] + "</td></tr>";
					html += newHTML;
				}
			});
			listEle.html(html);
			listEle.appendTo('#gamelist');
			$('<br/>').appendTo('#gamelist');
		});
	});
};