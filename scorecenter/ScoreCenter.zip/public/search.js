var searchUsers = function() {
	var button = document.getElementById('submit');
	button.setAttribute('disabled', 1);
	var table = document.getElementById('usertable');
	if (table) {
		table.parentNode.removeChild(table);
	}
	var username = document.getElementById('input').value;
	if (!username) {
		button.removeAttribute('disabled');
		return;
	}
	$.getJSON('./allscores.json', function(data) {
		button.removeAttribute('disabled');

		var scorelist = data['data'];
		scorelist.sort(function(a, b) {
			return b['score'] - a['score'];
		});

		var listEle = $('<table/>', {
			'class': 'scoretable',
			'id': 'usertable',
			'border': '2',
			html: ""
		});

		var html = "<tr><th>Game</th><th>Score</th><th>Time</th></tr>";
		$.each(scorelist, function(j, score) {
			if (username && score['username'] == username) {
				var newHTML = "";
				newHTML = "<tr><td>" + score['game_title'] + "</td>";
				newHTML += "<td>" + score['score'] + "</td>";
				newHTML += "<td>" + score['created_at'] + "</td></tr>";
				html += newHTML;
			}
		});
		listEle.html(html);
		listEle.appendTo('#scorelist');
	});
};